# Contributing

Lichii is developed in this fork. Open issues and pull requests on
[zortos293/eglantine](https://github.com/zortos293/eglantine).

See the [build guide](docs/Build.md) for your platform and the
[coding guidelines](docs/Coding.md) for technical guidance. Keep changes focused,
describe what you tested, and distinguish build checks from gameplay testing.

Original copyright notices and third-party licenses remain in effect. See
[LICENSE.txt](LICENSE.txt) for the project's license.
